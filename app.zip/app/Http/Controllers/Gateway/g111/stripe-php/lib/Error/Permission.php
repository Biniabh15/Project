<?php

namespace StripeJS\Error;

class Permission extends Base
{
}
